descriptor:command2
-------------------

* Description: command 2 description
* Usage:

  * `descriptor:command2 [-o|--option_name] [--] <argument_name>`
  * `descriptor:command2 -o|--option_name <argument_name>`
  * `descriptor:command2 <argument_name>`

command 2 help

### Arguments:

**argument_name:**

* Name: argument_name
* Is required: yes
* Is array: no
* Description: <none>
* Default: `NULL`

### Options:

**option_name:**

* Name: `--option_name`
* Shortcut: `-o`
* Accept value: no
* Is value required: no
* Is multiple: no
* Description: <none>
* Default: `false`
