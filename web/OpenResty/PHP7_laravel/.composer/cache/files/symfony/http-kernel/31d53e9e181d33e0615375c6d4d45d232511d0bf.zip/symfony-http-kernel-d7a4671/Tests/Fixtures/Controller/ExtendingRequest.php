<?php

namespace Symfony\Component\HttpKernel\Tests\Fixtures\Controller;

use Symfony\Component\HttpFoundation\Request;

class ExtendingRequest extends Request
{
}
